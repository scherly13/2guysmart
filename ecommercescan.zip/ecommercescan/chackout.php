<!DOCTYPE html>
<?php
session_start();

// Calculate subtotal
$subtotal = 0;
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
}
$shipping = 3.00; // Flat rate shipping
$total = $subtotal + $shipping; // Calculate total
?>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>2Guys Mart</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" role="status"></div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar start -->
        <div class="container-fluid fixed-top">
            <div class="container topbar bg-primary d-none d-lg-block">
                <div class="d-flex justify-content-between">
                    <div class="top-info ps-2">
                        <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#" class="text-white">UMSKAL,LABUAN</a></small>
                        <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#" class="text-white">welcometo2guysmart@gmail.com</a></small>
                    </div>
                </div>
            </div>
            <div class="container px-0">
                <nav class="navbar navbar-light bg-white navbar-expand-xl">
                    <a href="index.php" class="navbar-brand"><h1 class="text-primary display-6">2Guys Mart</h1></a>
                    <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                        <div class="navbar-nav mx-auto">
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="shop.php" class="nav-item nav-link">Shop</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0 bg-secondary rounded-0">
                                    <a href="cart.php" class="dropdown-item">Cart</a>
                                    <a href="chackout.php" class="dropdown-item">Chackout</a>
                                </div>
                        </div>
						
						<?php
// echo '<pre>';
// print_r($_SESSION['cart']);
// echo '</pre>';

// Initialize total quantity
$totalQuantity = 0;

// Check if cart has items and calculate total quantity
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $item) {
        // Ensure each item has a 'quantity' key before summing
        if (isset($item['quantity'])) {
            $totalQuantity += $item['quantity'];
        }
    }
}
?>

<div class="d-flex m-3 me-0">
    <!-- Search Button -->
    <button class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-4" 
            data-bs-toggle="modal" data-bs-target="#searchModal">
        <i class="fas fa-search text-primary"></i>
    </button>

    <!-- Cart Icon with Dynamic Quantity -->
    <a href="cart.php" class="position-relative me-4 my-auto">
        <i class="fa fa-shopping-bag fa-2x"></i>
        <span class="position-absolute bg-circles rounded-circle d-flex align-items-center justify-content-center text-dark px-1" 
              style="top: -5px; left: 15px; height: 20px; min-width: 20px;">
            <?php echo $totalQuantity; ?>
        </span>
    </a>
</div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Navbar End -->


        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Checkout</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-white">Checkout</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Checkout Page Start -->
        <?php
// Calculate subtotal from cart items
$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$shipping = 3.00; // Fixed shipping fee
$total = $subtotal + $shipping; // Grand total including shipping

// Function to insert order into the database when the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli("localhost", "root", "", "mart");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert order details into the orders table
    $stmt = $conn->prepare("INSERT INTO orders (first_name, last_name, address, mobile, email, payment_method, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssd", $_POST['first_name'], $_POST['last_name'], $_POST['address'], $_POST['mobile'], $_POST['email'], $_POST['payment_method'], $total);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    // Insert each cart item into the order_items table
    foreach ($_SESSION['cart'] as $item) {
        $item_subtotal = $item['price'] * $item['quantity'];
        $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_name, product_price, quantity, subtotal) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isdid", $order_id, $item['name'], $item['price'], $item['quantity'], $item_subtotal);
        $stmt->execute();
    }
    $stmt->close();
    $conn->close();

    // Clear the cart session after the order is placed
    unset($_SESSION['cart']);
	
	$delete_query = "DELETE FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $stmt->close();
	
	// After processing the order and inserting data into the database
	echo "<script>
			alert('Order successfully placed.');
			window.location.href = 'invoice.php?order_id=" . $order_id . "';
		  </script>";
	exit();


}
?>

<!-- Checkout Page Start -->
<div class="container-fluid py-5">
    <div class="container py-5">
        <h1 class="mb-4">Billing details</h1>
        <form method="POST" action="">
            <div class="row g-5">
                <div class="col-md-12 col-lg-6 col-xl-7">
                    <!-- Billing Fields -->
                    <div class="row">
                        <div class="col-md-12 col-lg-6">
                            <label class="form-label my-3">First Name<sup>*</sup></label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <label class="form-label my-3">Last Name<sup>*</sup></label>
                            <input type="text" name="last_name" class="form-control" required>
                        </div>
                    </div>
                    <label class="form-label my-3">Address<sup>*</sup></label>
                    <input type="text" name="address" class="form-control" required>
                    <input type="text" name="postcode" class="form-control" required>
                    <label class="form-label my-3">Mobile<sup>*</sup></label>
                    <input type="tel" name="mobile" class="form-control" required>
                    <label class="form-label my-3">Email Address<sup>*</sup></label>
                    <input type="email" name="email" class="form-control" required>

                    <!-- Order Notes -->
                    <label class="form-label my-3">Order Notes</label>
                    <textarea name="order_notes" class="form-control" rows="5" placeholder="Order Notes (Optional)"></textarea>
                </div>

                <div class="col-md-12 col-lg-6 col-xl-5">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Products</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($_SESSION['cart'])): ?>
                                    <?php foreach ($_SESSION['cart'] as $item): ?>
                                        <tr>
                                            <td><img src="<?php echo htmlspecialchars($item['image']); ?>" class="img-fluid rounded-circle" style="width: 90px; height: 90px;"></td>
                                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                                            <td>RM<?php echo number_format($item['price'], 2); ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>RM<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="4" class="text-end py-5">
                                            <p class="mb-0 text-dark py-3">Subtotal</p>
                                        </td>
                                        <td class="py-5">
                                            <div class="py-3 border-bottom border-top">
                                                <p class="mb-0 text-dark">RM<?php echo number_format($subtotal, 2); ?></p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="text-end py-5">
                                            <p class="mb-0 text-dark py-3">Shipping</p>
                                        </td>
                                        <td class="py-5">
                                            <div class="py-3 border-bottom border-top">
                                                <p class="mb-0 text-dark">RM<?php echo number_format($shipping, 2); ?></p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" class="text-end py-5">
                                            <p class="mb-0 text-dark text-uppercase py-3">Total</p>
                                        </td>
                                        <td class="py-5">
                                            <div class="py-3 border-bottom border-top">
                                                <p class="mb-0 text-dark">RM<?php echo number_format($total, 2); ?></p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Your cart is empty.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Payment Method -->
                    <div class="my-3">
                        <label class="form-label">Select Payment Method:</label>
                        <select name="payment_method" class="form-select" required>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Check Payment">Check Payment</option>
                            <option value="Cash on Delivery">Cash on Delivery</option>
                            <option value="Paypal">Paypal</option>
                        </select>
                    </div>

                    <!-- Place Order Button -->
                    <div class="row g-4 text-center align-items-center justify-content-center pt-4">
                        <button type="submit" class="btn border-secondary py-3 px-4 text-uppercase w-100 text-primary">Place Order</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

        <!-- Checkout Page End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    </body>

</html>