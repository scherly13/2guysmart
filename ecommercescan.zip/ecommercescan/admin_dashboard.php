<?php
// Start the session if necessary and check if the user is an admin
session_start();
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
     header("Location: login.php");
     exit;
 }
// Connect to the database
include('database.php');

// Fetch Pending Orders Count
$pendingResult = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Pending'");
$pendingCount = $pendingResult->fetch_assoc()['count'];

// Fetch Shipped Orders Count
$shippedResult = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Shipped'");
$shippedCount = $shippedResult->fetch_assoc()['count'];

// Fetch Total Products Count
$productsResult = $conn->query("SELECT COUNT(*) as count FROM products");
$productsCount = $productsResult->fetch_assoc()['count'];

// Fetch Order Item Quantities by Product Category
$categoryResult = $conn->query("
    SELECT product_categories, SUM(quantity) AS total_quantity 
    FROM order_items 
    GROUP BY product_categories
");

$categories = [];
$categoryQuantities = [];

while ($row = $categoryResult->fetch_assoc()) {
    $categories[] = $row['product_categories'];
    $categoryQuantities[] = $row['total_quantity'];
}

// Fetch Monthly Sales Data for Graph
$monthlySalesResult = $conn->query("
    SELECT 
        MONTH(created_at) AS month, 
        SUM(total) AS total_sales 
    FROM orders 
    WHERE YEAR(created_at) = YEAR(CURDATE()) 
    GROUP BY MONTH(created_at) 
    ORDER BY MONTH(created_at)
");

$months = [];
$totalSalesData = [];
while ($row = $monthlySalesResult->fetch_assoc()) {
    $months[] = date("M", mktime(0, 0, 0, $row['month'], 10));
    $totalSalesData[] = $row['total_sales'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
       
        .card {
            background-color: #e0e4cc;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            color: #333;
            text-align: center;
        }
        .chart-container {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .chart {
            flex: 1;
            background-color: #d1e0d5;
            border-radius: 8px;
            padding: 20px;
        }
    </style>
</head>
<body>
<?php include ('sidebar.php'); ?>
<div class="container">
    <h2 class="mb-4 text-center">Admin Dashboard</h2>
    <div class="row text-center">
        <!-- Status Cards with PHP Data -->
        <div class="col-md-4">
            <div class="card">
                <h5>Pending Orders</h5>
                <p><?php echo $pendingCount; ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <h5>Shipped Orders</h5>
                <p><?php echo $shippedCount; ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <h5>Total Products</h5>
                <p><?php echo $productsCount; ?></p>
            </div>
        </div>
    </div>

    <!-- Chart Section -->
    <div class="chart-container">
        <div class="chart">
            <h5 class="text-center">Order Items by Category</h5>
            <canvas id="categoryChart"></canvas>
        </div>
        <div class="chart">
            <h5 class="text-center">Monthly Sales Overview</h5>
            <canvas id="monthlySalesChart"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Order Items by Category Chart with Data from PHP
    const categories = <?php echo json_encode($categories); ?>;
    const categoryQuantities = <?php echo json_encode($categoryQuantities); ?>;

    // Function to generate random colors
function getRandomColors(numColors) {
    const colors = [];
    for (let i = 0; i < numColors; i++) {
        // Generate bold RGB colors by setting one color channel low and the others high
        const r = Math.floor(Math.random() * 156) + 100; // 100-255 for brightness
        const g = Math.floor(Math.random() * 156) + 100;
        const b = Math.floor(Math.random() * 156) + 100;
        
        const color = `rgba(${r}, ${g}, ${b}, 1)`; // Alpha set to 1 for boldness
        colors.push(color);
    }
    return colors;
}

// Generate random colors based on the number of categories
const backgroundColors = getRandomColors(categories.length);

// Order Items by Category Chart with Data from PHP
const ctx1 = document.getElementById('categoryChart').getContext('2d');
new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: categories,
        datasets: [{
            label: 'Quantity',
            data: categoryQuantities,
            backgroundColor: backgroundColors
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                title: {
                    display: true,
                    text: 'Quantity'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Product Category'
                }
            }
        }
    }
});


    // Monthly Sales Overview Chart with Data from PHP
    const months = <?php echo json_encode($months); ?>;
    const totalSalesData = <?php echo json_encode($totalSalesData); ?>;

    const ctx2 = document.getElementById('monthlySalesChart').getContext('2d');
    new Chart(ctx2, {
        type: 'line',
        data: {
            labels: months,
            datasets: [
                {
                    label: 'Total Sales',
                    data: totalSalesData,
                    borderColor: '#36A2EB',
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true }
            },
            scales: {
                y: {
                    title: {
                        display: true,
                        text: 'Sales Amount ($)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Month'
                    }
                }
            }
        }
    });
</script>

</body>
</html>
