<?php
session_start();

// Read the JSON input sent from the JavaScript
$input = file_get_contents("php://input");
$newCartData = json_decode($input, true);

if (is_array($newCartData)) {
    // Clear the existing session cart
    $_SESSION['cart'] = [];

    // Add the new cart items to the session
    foreach ($newCartData as $productId => $item) {
        $_SESSION['cart'][$productId] = [
            'name' => $item['name'],
            'price' => $item['price'],
            'quantity' => $item['quantity'],
        ];
    }

    // Return a success response
    echo json_encode(['success' => true]);
} else {
    // Return an error response if the data is invalid
    echo json_encode(['success' => false, 'message' => 'Invalid cart data']);
}
?>
