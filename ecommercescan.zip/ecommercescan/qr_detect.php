<?php
session_start();
$conn = new mysqli("localhost", "root", "", "mart");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Dummy user_id
$user_id = 1;

// Check if product_id is set in the URL
if (isset($_GET['product_id'])) {
    $product_id = (int)$_GET['product_id'];

    // Check if the product already exists in the cart for the user
    $check_query = "SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If product exists in the cart, update the quantity
        $update_query = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("ii", $user_id, $product_id);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        // If product does not exist in the cart, insert it with quantity 1
        $insert_query = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("ii", $user_id, $product_id);
        $insert_stmt->execute();
        $insert_stmt->close();
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Added to Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container text-center mt-5">
    <h1 class="text-success">Success</h1>
    <p>The product has been successfully added to your cart.</p>

</div>
</body>
</html>
