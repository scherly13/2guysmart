<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "mart");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 1; // Dummy user_id for demonstration

// Fetch items from the database cart table
$cart_query = "
    SELECT c.product_id, c.quantity, p.name, p.price, p.image_url 
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
";
$stmt = $conn->prepare($cart_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$db_cart_result = $stmt->get_result();

// Store database cart items in an associative array
$db_cart_items = [];
while ($row = $db_cart_result->fetch_assoc()) {
    $db_cart_items[$row['product_id']] = [
        'name' => $row['name'],
        'price' => $row['price'],
        'quantity' => $row['quantity'],
        'image' => $row['image_url'],
    ];
}

// Combine session cart data with database cart items
$combined_cart_items = $db_cart_items;
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $session_item) {
        // If item exists in both session and database, add quantities
        if (isset($combined_cart_items[$product_id])) {
            $combined_cart_items[$product_id]['quantity'] += $session_item['quantity'];
        } else {
            // Item only in session cart, add it directly
            $combined_cart_items[$product_id] = $session_item;
        }
    }
}

echo json_encode($combined_cart_items);
$stmt->close();
$conn->close();
?>
