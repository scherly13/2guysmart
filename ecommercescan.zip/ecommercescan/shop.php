<!DOCTYPE html>
<?php
session_start(); // Start session to access cart data
?>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>2Guys Mart</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" role="status"></div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar start -->
        <div class="container-fluid fixed-top">
            <div class="container topbar bg-primary d-none d-lg-block">
                <div class="d-flex justify-content-between">
                    <div class="top-info ps-2">
                        <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#" class="text-white">UMSKAL,LABUAN</a></small>
                        <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#" class="text-white">welcometo2guysmart@gmail.com</a></small>
                    </div>
                </div>
            </div>
            <div class="container px-0">
                <nav class="navbar navbar-light bg-white navbar-expand-xl">
                    <a href="index.php" class="navbar-brand"><h1 class="text-primary display-6">2Guys Mart</h1></a>
                    <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                        <div class="navbar-nav mx-auto">
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="shop.php" class="nav-item nav-link">Shop</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0 bg-secondary rounded-0">
                                    <a href="cart.php" class="dropdown-item">Cart</a>
                                    <a href="chackout.php" class="dropdown-item">Chackout</a>
                                </div>
                        </div>
                       <?php
// echo '<pre>';
// print_r($_SESSION['cart']);
// echo '</pre>';

// Initialize total quantity
$totalQuantity = 0;

// Check if cart has items and calculate total quantity
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $item) {
        // Ensure each item has a 'quantity' key before summing
        if (isset($item['quantity'])) {
            $totalQuantity += $item['quantity'];
        }
    }
}
?>

<div class="d-flex m-3 me-0">
    <!-- Search Button -->
    <button class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-4" 
            data-bs-toggle="modal" data-bs-target="#searchModal">
        <i class="fas fa-search text-primary"></i>
    </button>

    <!-- Cart Icon with Dynamic Quantity -->
    <a href="cart.php" class="position-relative me-4 my-auto">
        <i class="fa fa-shopping-bag fa-2x"></i>
        <span class="position-absolute bg-circles rounded-circle d-flex align-items-center justify-content-center text-dark px-1" 
              style="top: -5px; left: 15px; height: 20px; min-width: 20px;">
            <?php echo $totalQuantity; ?>
        </span>
    </a>
</div>
                </nav>
            </div>
        </div>
        <!-- Navbar End -->


        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Shop</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-white">Shop</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Fruits Shop Start-->
<?php

// Function to connect to the database
function getDatabaseConnection() {
    $conn = new mysqli("localhost", "root", "", "mart");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Function to fetch categories with product counts
function fetchCategories($conn) {
    $query = "SELECT category, COUNT(*) as count FROM products GROUP BY category";
    $result = $conn->query($query);
    if (!$result) {
        die("Error fetching categories: " . $conn->error);
    }
    return $result;
}

// Function to fetch featured products
function fetchFeaturedProducts($conn, $category = 'Fruits', $limit = 3) {
    $query = "SELECT * FROM products WHERE category = ? ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $category, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$result) {
        die("Error fetching featured products: " . $conn->error);
    }
    return $result;
}

// Function to get the total number of products for pagination with category filter
function getTotalProducts($conn, $category = null) {
    $query = "SELECT COUNT(*) as total FROM products";
    if ($category && $category != 'All') {
        $query .= " WHERE category = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $category);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($query);
    }
    if (!$result) {
        die("Error fetching total products count: " . $conn->error);
    }
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Function to fetch main products for the current page with category filter
function fetchMainProducts($conn, $limit, $offset, $category = null) {
    $query = "SELECT * FROM products";
    if ($category && $category != 'All') {
        $query .= " WHERE category = ?";
    }
    $query .= " LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($query);
    if ($category && $category != 'All') {
        $stmt->bind_param("sii", $category, $limit, $offset);
    } else {
        $stmt->bind_param("ii", $limit, $offset);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$result) {
        die("Error fetching main products: " . $conn->error);
    }
    return $result;
}

// Handle "Add to cart" request
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_category = $_POST['product_category'];

    // If the cart session doesn't exist, initialize it
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the product is already in the cart
    if (isset($_SESSION['cart'][$product_id])) {
        // Increase the quantity if the product is already in the cart
        $_SESSION['cart'][$product_id]['quantity'] += 1;
				echo "<script>alert('Cart successfull updated.');</script>";

    } else {
        // Add the product to the cart with quantity 1
        $_SESSION['cart'][$product_id] = [
            'name' => $product_name,
            'price' => $product_price,
            'image' => $product_image,
			'category' => $product_category,
            'quantity' => 1
        ];
		echo "<script>alert('Cart successfull updated.');</script>";
    }
}



// Initialize database connection
$conn = getDatabaseConnection();

// Fetch categories and product count
$categories_result = fetchCategories($conn);

// Get selected category from URL, defaulting to "All" if not set
$selected_category = isset($_GET['category']) ? $_GET['category'] : 'All';

// Fetch featured products
$featured_result = fetchFeaturedProducts($conn, $selected_category !== 'All' ? $selected_category : 'Fruits');

// Set the number of products per page
$products_per_page = 9;

// Get the current page from the URL, defaulting to 1 if not set
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $products_per_page;

// Get total products count and calculate total pages, with category filter if selected
$total_products = getTotalProducts($conn, $selected_category);
$total_pages = ceil($total_products / $products_per_page);

// Fetch main products for the current page, with category filter if selected
$main_products_result = fetchMainProducts($conn, $products_per_page, $offset, $selected_category);

// Close the database connection when done
$conn->close();
?>

<div class="container-fluid fruite py-5">
    <div class="container py-5">
        <h1 class="mb-4">Fresh fruits shop</h1>
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="row g-4">
                    <!-- Categories Sidebar -->
                    <div class="col-lg-3">
                        <div class="row g-4">
                            <!-- Categories with Product Counts -->
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <h4>Categories</h4>
                                    <ul class="list-unstyled fruite-categorie">
                                        <!-- Hard-coded "All" category -->
                                        <li>
                                            <div class="d-flex justify-content-between fruite-name">
                                                <a href="?category=All"><i class="fas fa-apple-alt me-2"></i>All</a>
                                                <span>(<?php echo $total_products; ?>)</span>
                                            </div>
                                        </li>
                                        <?php while ($category = $categories_result->fetch_assoc()): ?>
                                            <li>
                                                <div class="d-flex justify-content-between fruite-name">
                                                    <a href="?category=<?php echo urlencode($category['category']); ?>"><i class="fas fa-apple-alt me-2"></i><?php echo $category['category']; ?></a>
                                                    <span>(<?php echo $category['count']; ?>)</span>
                                                </div>
                                            </li>
                                        <?php endwhile; ?>
                                    </ul>
                                </div>
                            </div>
                            <!-- Additional filters, featured products, etc., can remain as they are in your original layout -->
                        </div>
                    </div>
                    
                    <!-- Main Product Display Section -->
                    <div class="col-lg-9">
                        <div class="row g-4 justify-content-center">
                            <?php while ($product = $main_products_result->fetch_assoc()): ?>
                                <div class="col-md-6 col-lg-6 col-xl-4">
                                    <div class="rounded position-relative fruite-item">
                                        <div class="fruite-img">
                                            <img src="<?php echo $product['image_url']; ?>" class="img-fluid w-100 rounded-top" alt="">
                                        </div>
                                        <div class="text-white bg-secondary px-3 py-1 rounded position-absolute" style="top: 10px; left: 10px;"><?php echo $product['category']; ?></div>
                                        <div class="p-4 border border-secondary border-top-0 rounded-bottom">
                                            <h4><?php echo $product['name']; ?></h4>
                                            <p><?php echo $product['description']; ?></p>
                                            <div class="d-flex justify-content-between flex-lg-wrap">
                                                <p class="text-dark fs-5 fw-bold mb-0">RM<?php echo $product['price']; ?></p>
                                                <!-- Add to Cart Form -->
                                                <form method="post" action="">
                                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                    <input type="hidden" name="product_name" value="<?php echo $product['name']; ?>">
                                                    <input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">
													<input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">
                                                    <input type="hidden" name="product_category" value="<?php echo $product['category']; ?>">
													<input type="hidden" name="product_image" value="<?php echo $product['img_url']; ?>">

                                                    <button type="submit" name="add_to_cart" class="btn border border-secondary rounded-pill px-3 text-primary">
                                                        <i class="fa fa-shopping-bag me-2 text-primary"></i> Add to cart
                                                    </button>
													<button type="button" onclick="displayQRCode(<?php echo $product['id']; ?>)" class="btn border border-secondary rounded-pill px-3 text-primary">
                                                        <i class="fa fa-qrcode me-2 text-primary"></i> Show QR
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                            
                            <!-- Pagination Section -->
                            <div class="col-12">
                                <div class="pagination d-flex justify-content-center mt-5">
                                    <?php if ($current_page > 1): ?>
                                        <a href="?page=<?php echo $current_page - 1; ?>&category=<?php echo urlencode($selected_category); ?>" class="rounded">&laquo;</a>
                                    <?php endif; ?>
                                    
                                    <?php for ($page = 1; $page <= $total_pages; $page++): ?>
                                        <a href="?page=<?php echo $page; ?>&category=<?php echo urlencode($selected_category); ?>" class="rounded <?php if ($page == $current_page) echo 'active'; ?>"><?php echo $page; ?></a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($current_page < $total_pages): ?>
                                        <a href="?page=<?php echo $current_page + 1; ?>&category=<?php echo urlencode($selected_category); ?>" class="rounded">&raquo;</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- QR Code Modal -->
<div class="modal fade" id="qrModal" tabindex="-1" aria-labelledby="qrModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="qrModalLabel">Product QR Code</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <!-- Dummy QR Code -->
                <img id="qrCodeImage" src="https://api.qrserver.com/v1/create-qr-code/?data=dummy&size=150x150" alt="QR Code" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<script>
function displayQRCode(productId) {
    // Generate QR code with the qr_detect.php URL
    const qrUrl = '192.168.184.161/ecommercescan/qr_detect.php?product_id=' + productId;
    document.getElementById('qrCodeImage').src = 'https://api.qrserver.com/v1/create-qr-code/?data=' + encodeURIComponent(qrUrl) + '&size=150x150';
    var qrModal = new bootstrap.Modal(document.getElementById('qrModal'), {});
    qrModal.show();
}

</script>


        <!-- Fruits Shop End-->



        <!-- Back to Top -->
        <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    </body>

</html>