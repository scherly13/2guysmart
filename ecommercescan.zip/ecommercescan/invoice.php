<?php
session_start();

// Check if an order ID is provided (e.g., passed from the order confirmation page)
if (!isset($_GET['order_id'])) {
    echo "Order ID not specified.";
    exit;
}

$order_id = $_GET['order_id'];

include('database.php');


// Retrieve order details
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();
$order = $order_result->fetch_assoc();
$stmt->close();

if (!$order) {
    echo "Order not found.";
    exit;
}

// Retrieve order items
$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice - Order #<?php echo $order_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .invoice-container {
			margin-top:100px important!;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .thank-you {
            color: #28a745;
            font-size: 1.25rem;
        }
    </style>
</head>
<head>
        <meta charset="utf-8">
        <title>2Guys Mart</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>


  <!-- Navbar start -->
        <div class="container-fluid fixed-top">
            <div class="container topbar bg-primary d-none d-lg-block">
                <div class="d-flex justify-content-between">
                    <div class="top-info ps-2">
                        <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#" class="text-white">123 Street, New York</a></small>
                        <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#" class="text-white">Email@Example.com</a></small>
                    </div>
                    <div class="top-link pe-2">
                        <a href="#" class="text-white"><small class="text-white mx-2">Privacy Policy</small>/</a>
                        <a href="#" class="text-white"><small class="text-white mx-2">Terms of Use</small>/</a>
                        <a href="#" class="text-white"><small class="text-white ms-2">Sales and Refunds</small></a>
                    </div>
                </div>
            </div>
            <div class="container px-0">
                <nav class="navbar navbar-light bg-white navbar-expand-xl">
                    <a href="index.php" class="navbar-brand"><h1 class="text-primary display-6">2Guys Mart</h1></a>
                    <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                        <div class="navbar-nav mx-auto">
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="shop.php" class="nav-item nav-link">Shop</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0 bg-secondary rounded-0">
                                    <a href="cart.php" class="dropdown-item">Cart</a>
                                    <a href="chackout.php" class="dropdown-item">Chackout</a>
                                </div>
                            </div>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <?php
// echo '<pre>';
// print_r($_SESSION['cart']);
// echo '</pre>';

// Initialize total quantity
$totalQuantity = 0;

// Check if cart has items and calculate total quantity
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $item) {
        // Ensure each item has a 'quantity' key before summing
        if (isset($item['quantity'])) {
            $totalQuantity += $item['quantity'];
        }
    }
}
?>

<div class="d-flex m-3 me-0">
    <!-- Search Button -->
    <button class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-4" 
            data-bs-toggle="modal" data-bs-target="#searchModal">
        <i class="fas fa-search text-primary"></i>
    </button>

    <!-- Cart Icon with Dynamic Quantity -->
    <a href="cart.php" class="position-relative me-4 my-auto">
        <i class="fa fa-shopping-bag fa-2x"></i>
        <span class="position-absolute bg-circles rounded-circle d-flex align-items-center justify-content-center text-dark px-1" 
              style="top: -5px; left: 15px; height: 20px; min-width: 20px;">
            <?php echo $totalQuantity; ?>
        </span>
    </a>
</div>


                    </div>
                </nav>
            </div>
        </div>
      
<div class="container-fluid fruite py-5">
<br><br><br>

<div class="invoice-container py-5">
<div class="container my-3">
<button onclick="window.location.href='shop.php'" class="btn btn-secondary">Back</button>
</div>
    <h2 class="text-center mb-4">Invoice - Order #<?php echo $order_id; ?></h2>
    
    <!-- Billing Details -->
    <h4>Billing Details</h4>
    <p><strong>First Name:</strong> <?php echo htmlspecialchars($order['first_name']); ?></p>
    <p><strong>Last Name:</strong> <?php echo htmlspecialchars($order['last_name']); ?></p>
    <p><strong>Company Name:</strong> <?php echo htmlspecialchars($order['company_name']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
    <p><strong>City:</strong> <?php echo htmlspecialchars($order['city']); ?></p>
    <p><strong>Country:</strong> <?php echo htmlspecialchars($order['country']); ?></p>
    <p><strong>Postcode/Zip:</strong> <?php echo htmlspecialchars($order['postcode']); ?></p>
    <p><strong>Mobile:</strong> <?php echo htmlspecialchars($order['mobile']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>

    <hr>

    <!-- Order Summary -->
    <h4>Order Summary</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $subtotal = 0;
            while ($item = $order_items_result->fetch_assoc()): 
                $subtotal += $item['subtotal'];
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td>RM<?php echo number_format($item['product_price'], 2); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>RM<?php echo number_format($item['subtotal'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-end">Subtotal</td>
                <td>RM<?php echo number_format($subtotal, 2); ?></td>
            </tr>
            <tr>
                <td colspan="3" class="text-end">Shipping</td>
                <td>RM3.00</td>
            </tr>
            <tr>
                <td colspan="3" class="text-end">Total</td>
                <td>RM<?php echo number_format($subtotal + 3, 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <hr>

    <!-- Thank You and Shipping Estimate -->
    <p class="thank-you text-center mt-4">Thank you for your purchase! </p>
</div>

</body>
</html>
