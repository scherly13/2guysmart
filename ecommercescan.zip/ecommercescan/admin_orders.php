<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
     header("Location: login.php");
     exit;
}

// Connect to the database
include('database.php');

// Handle order status update
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $order_status = $_POST['order_status'];

    echo "<p>Debug: Order ID - $order_id</p>";
    echo "<p>Debug: Order Status - $order_status</p>";

    if ($stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?")) {
        $stmt->bind_param("si", $order_status, $order_id);

        if ($stmt->execute()) {
            echo "<p>Debug: Order status updated in the database.</p>";
        } else {
            echo "<p>Error: Could not execute update statement.</p>";
        }
        
        $stmt->close();
    } else {
        echo "<p>Error: Could not prepare update statement.</p>";
    }

    // Redirect with success message
    echo "<script>alert('Order status updated successfully.'); window.location.href = 'admin_orders.php';</script>";
    exit;
}

// Handle order deletion
if (isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];

    echo "<p>Debug: Deleting Order ID - $order_id</p>";

    // Delete order items first
    if ($stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?")) {
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
        echo "<p>Debug: Order items deleted.</p>";
    } else {
        echo "<p>Error: Could not prepare delete order items statement.</p>";
    }

    // Delete the order itself
    if ($stmt = $conn->prepare("DELETE FROM orders WHERE id = ?")) {
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
        echo "<p>Debug: Order deleted.</p>";
    } else {
        echo "<p>Error: Could not prepare delete order statement.</p>";
    }

    // Redirect with success message
    echo "<script>alert('Order deleted successfully.'); window.location.href = 'admin_orders.php';</script>";
    exit;
}

// Retrieve all orders
$result = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet"></head>
</head>
<body>
<?php include('sidebar.php'); ?>

<div class="container my-5">
    <h2 class="text-center mb-4">Manage Orders</h2>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Email</th>
                <th>Total</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $no; ?></td>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo htmlspecialchars($order['first_name'] . " " . $order['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['email']); ?></td>
                    <td>$<?php echo number_format($order['total'], 2); ?></td>
                    <td>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <select name="order_status" class="form-select" onchange="this.form.submit()">
                                <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Shipped" <?php if ($order['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
                           </select>
                            <input type="hidden" name="update_status" value="1">
                        </form>
                    </td>
                    <td><?php echo date("Y-m-d H:i", strtotime($order['created_at'])); ?></td>
                    <td>
                        <a href="admin_invoice.php?order_id=<?php echo $order['id']; ?>" class="btn btn-info btn-sm">View</a>
                        <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this order?');">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <button type="submit" name="delete_order" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php 
            $no++;
            endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
