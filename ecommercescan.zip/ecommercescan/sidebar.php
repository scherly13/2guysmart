<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar and Topbar UI</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            transition: margin-left 0.3s;
        }

        .sidebar {
            background-color: #556B2F;
            width: 300px; /* Increased width for more prominence */
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px;
            color: #fff;
            overflow-y: auto; /* Enable scrolling if content overflows */
            transition: margin-left 0.3s;
        }

        .sidebar h2 {
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 15px 0; /* Increased padding for more height per title */
            text-decoration: none;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background-color: #34495e;
            border-radius: 4px;
        }

        .main-content {
            margin-left: 300px; /* Adjusted for new sidebar width */
            width: calc(100% - 300px); /* Adjusted width */
            transition: margin-left 0.3s, width 0.3s;
			background-color: #FFFDD0;
        }

        .topbar {
            background-color: #FFFDD0;
            padding: 15px;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: margin-left 0.3s;
			    border: 3px solid black; /* Adds a black border */

        }

        .topbar button {
            font-size: 24px;
            background: none;
            border: none;
            color: #000;
            cursor: pointer;
        }

        .content {
            padding: 20px;
        }

        /* Toggle behavior */
        .sidebar.active {
            margin-left: -300px; /* Adjusted for new sidebar width */
        }

        .main-content.active {
            margin-left: 0;
            width: 100%;
        }

        .topbar.active {
            margin-left: 0;
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <h2 style="color:white;">Admin</h2>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="admin_shop.php">Product</a>
        <a href="admin_categories.php">Categories</a>
        <a href="admin_orders.php">Orders</a>
    </div>

    <div class="main-content" id="mainContent">
        <div class="topbar" id="topbar">
            <button id="toggle-btn" onclick="toggleSidebar()">☰</button>
            <h3><a href="logout.php" style="text-decoration: none; color: inherit;">Logout</a></h3>
        </div>
        
        <!-- Your content here -->
        

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const topbar = document.getElementById('topbar');

            sidebar.classList.toggle('active');
            mainContent.classList.toggle('active');
            topbar.classList.toggle('active');
        }
    </script>
</body>
</html>
