<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php");
    exit;
}
include('database.php');

// Fetch categories for the dropdown
function fetchCategoriesDropdown($conn) {
    $query = "SELECT name FROM categories";
    $result = $conn->query($query);
    if (!$result) {
        die("Error fetching categories: " . $conn->error);
    }
    return $result;
}

$categories_dropdown = fetchCategoriesDropdown($conn);

// Handle category selection
$selected_category = isset($_GET['category']) ? $_GET['category'] : 'All';
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$products_per_page = 10;
$offset = ($current_page - 1) * $products_per_page;

// Fetch products with pagination and category filter
function fetchProducts($conn, $selected_category, $products_per_page, $offset) {
    $query = "SELECT * FROM products";
    if ($selected_category != 'All') {
        $query .= " WHERE category = ?";
    }
    $query .= " LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($query);
    if ($selected_category != 'All') {
        $stmt->bind_param("sii", $selected_category, $products_per_page, $offset);
    } else {
        $stmt->bind_param("ii", $products_per_page, $offset);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return $result;
}

$products = fetchProducts($conn, $selected_category, $products_per_page, $offset);

// Count total products for pagination
$total_products_query = "SELECT COUNT(*) as total FROM products";
if ($selected_category != 'All') {
    $total_products_query .= " WHERE category = ?";
}
$stmt = $conn->prepare($total_products_query);
if ($selected_category != 'All') {
    $stmt->bind_param("s", $selected_category);
}
$stmt->execute();
$total_products_result = $stmt->get_result()->fetch_assoc();
$total_products = $total_products_result['total'];
$total_pages = ceil($total_products / $products_per_page);
$stmt->close();
?>

<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin - Manage Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet"></head>
</head>
<body>
<?php include('sidebar.php')?>

<div class="container py-5">
    <h1 class="mb-4">Manage Products</h1>
        <button class="btn btn-success mb-4" data-bs-toggle="modal" data-bs-target="#addProductModal">Add Product</button>

    <!-- Category Filter -->
    <div class="mb-4">
        <label for="categorySelect" class="form-label">Filter by Category:</label>
        <select id="categorySelect" class="form-select" onchange="filterByCategory(this.value)">
            <option value="All" <?php if ($selected_category == 'All') echo 'selected'; ?>>All</option>
            <?php while ($category = $categories_dropdown->fetch_assoc()): ?>
                <option value="<?php echo $category['name']; ?>" <?php if ($selected_category == $category['name']) echo 'selected'; ?>>
                    <?php echo $category['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $products->fetch_assoc()): ?>
                <tr>
                    <td><img src="<?php echo $product['image_url']; ?>" class="img-thumbnail" style="width: 80px; height: 80px;"></td>
                    <td><?php echo $product['name']; ?></td>
                    <td><?php echo $product['description']; ?></td>
                    <td>$<?php echo $product['price']; ?> / kg</td>
                    <td><?php echo $product['category']; ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm mb-1" onclick="setEditModal(<?php echo htmlspecialchars(json_encode($product)); ?>)" data-bs-toggle="modal" data-bs-target="#editProductModal">Edit</button>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" name="delete_product" class="btn btn-danger btn-sm mb-1">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php for ($page = 1; $page <= $total_pages; $page++): ?>
                <li class="page-item <?php if ($page == $current_page) echo 'active'; ?>">
                    <a class="page-link" href="?page=<?php echo $page; ?>&category=<?php echo urlencode($selected_category); ?>"><?php echo $page; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProductModalLabel">Add Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                </div>
                <div class="mb-3">
                    <label for="category" class="form-label">Category</label>
                    <select class="form-select" id="category" name="category" required>
                        <?php
                        $categories_dropdown->data_seek(0); // Reset pointer
                        while ($category = $categories_dropdown->fetch_assoc()): ?>
                            <option value="<?php echo $category['name']; ?>"><?php echo $category['name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Upload Image</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="add_product" class="btn btn-primary">Add Product</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="edit_product_id" name="product_id">
                <div class="mb-3">
                    <label for="edit_name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="edit_name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="edit_description" class="form-label">Description</label>
                    <textarea class="form-control" id="edit_description" name="description" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="edit_price" class="form-label">Price</label>
                    <input type="number" step="0.01" class="form-control" id="edit_price" name="price" required>
                </div>
                <div class="mb-3">
                    <label for="edit_category" class="form-label">Category</label>
                    <select class="form-select" id="edit_category" name="category" required>
                        <?php
                        $categories_dropdown->data_seek(0);
                        while ($category = $categories_dropdown->fetch_assoc()): ?>
                            <option value="<?php echo $category['name']; ?>"><?php echo $category['name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="edit_image" class="form-label">Upload New Image (optional)</label>
                    <input type="file" class="form-control" id="edit_image" name="edit_image">
                    <input type="hidden" id="existing_image_url" name="existing_image_url">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="edit_product" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function filterByCategory(category) {
    window.location.href = "?category=" + encodeURIComponent(category) + "&page=1";
}

function setEditModal(product) {
    document.getElementById('edit_product_id').value = product.id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_description').value = product.description;
    document.getElementById('edit_price').value = product.price;
    document.getElementById('edit_category').value = product.category;
    document.getElementById('existing_image_url').value = product.image_url;
}
</script>
</body>
</html>
