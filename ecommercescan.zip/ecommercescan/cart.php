<!DOCTYPE html>
<?php
session_start(); // Start session to access cart data
?>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>2Guys Mart</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <!-- Spinner Start -->
        <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" role="status"></div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar start -->
        <div class="container-fluid fixed-top">
            <div class="container topbar bg-primary d-none d-lg-block">
                <div class="d-flex justify-content-between">
                    <div class="top-info ps-2">
                        <small class="me-3"><i class="fas fa-map-marker-alt me-2 text-secondary"></i> <a href="#" class="text-white">UMSKAL,LABUAN</a></small>
                        <small class="me-3"><i class="fas fa-envelope me-2 text-secondary"></i><a href="#" class="text-white">welcometo2guysmart@gmail.com</a></small>
                    </div>
                </div>
            </div>
            <div class="container px-0">
                <nav class="navbar navbar-light bg-white navbar-expand-xl">
                    <a href="index.php" class="navbar-brand"><h1 class="text-primary display-6">2Guys Mart</h1></a>
                    <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="fa fa-bars text-primary"></span>
                    </button>
                    <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                        <div class="navbar-nav mx-auto">
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="shop.php" class="nav-item nav-link">Shop</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu m-0 bg-secondary rounded-0">
                                    <a href="cart.php" class="dropdown-item">Cart</a>
                                    <a href="chackout.php" class="dropdown-item">Chackout</a>
                                </div>
                            </div>
                        </div>
                        <?php
// echo '<pre>';
// print_r($_SESSION['cart']);
// echo '</pre>';

// Initialize total quantity
$totalQuantity = 0;

// Check if cart has items and calculate total quantity
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $item) {
        // Ensure each item has a 'quantity' key before summing
        if (isset($item['quantity'])) {
            $totalQuantity += $item['quantity'];
        }
    }
}
?>

<div class="d-flex m-3 me-0">
    <!-- Search Button -->
    <button class="btn-search btn border border-secondary btn-md-square rounded-circle bg-white me-4" 
            data-bs-toggle="modal" data-bs-target="#searchModal">
        <i class="fas fa-search text-primary"></i>
    </button>

    <!-- Cart Icon with Dynamic Quantity -->
    <a href="cart.php" class="position-relative me-4 my-auto">
        <i class="fa fa-shopping-bag fa-2x"></i>
        <span class="position-absolute bg-circles rounded-circle d-flex align-items-center justify-content-center text-dark px-1" 
              style="top: -5px; left: 15px; height: 20px; min-width: 20px;">
            <?php echo $totalQuantity; ?>
        </span>
    </a>
</div>
                    </div>
                </nav>
            </div>
                </nav>
            </div>
        </div>
        <!-- Navbar End -->


        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Single Page Header start -->
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Cart</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-white">Cart</li>
            </ol>
        </div>
        <!-- Single Page Header End -->


        <!-- Cart Page Start -->
<?php
// Start PHP session
$conn = new mysqli("localhost", "root", "", "mart");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 1;

// Remove item functionality
if (isset($_POST['remove_product_id'])) {
    $product_id = $_POST['remove_product_id'];
    unset($_SESSION['cart'][$product_id]);

    $delete_query = "DELETE FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $stmt->close();
}
?>

<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="table-responsive">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Products</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                    <th scope="col">Handle</th>
                  </tr>
                </thead>
                <tbody id="cart-table-body">
                    <!-- Cart items will be dynamically inserted here by JavaScript -->
                </tbody>
            </table>
        </div>
        
        <div class="row g-4 justify-content-end">
            <div class="col-8"></div>
            <div class="col-sm-8 col-md-7 col-lg-6 col-xl-4">
                <div class="bg-light rounded">
                    <div class="p-4">
                        <h1 class="display-6 mb-4">Cart <span class="fw-normal">Total</span></h1>
                        <div class="d-flex justify-content-between mb-4">
                            <h5 class="mb-0 me-4">Subtotal:</h5>
                            <p class="mb-0" id="subtotal">RM0.00</p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h5 class="mb-0 me-4">Shipping</h5>
                            <div class="">
                                <p class="mb-0">Flat rate: RM3.00</p>
                            </div>
                        </div>
                        <p class="mb-0 text-end">Shipping to your location.</p>
                    </div>
                    <div class="py-4 mb-4 border-top border-bottom d-flex justify-content-between">
                        <h5 class="mb-0 ps-4 me-4">Total</h5>
                        <p class="mb-0 pe-4" id="total">RM0.00</p>
                    </div>
                    <button class="btn border-secondary rounded-pill px-4 py-3 text-primary text-uppercase mb-4 ms-4" type="button" onclick="proceedToCheckout()">Proceed Checkout</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function proceedToCheckout() {
        const cartData = {};

        // Collect the current cart data from the displayed items
        for (const productId in previousCartData) {
            const quantity = parseInt(document.getElementById(`quantity-${productId}`).value) || 0;
            if (quantity > 0) {
                cartData[productId] = {
                    name: previousCartData[productId].name,
                    price: previousCartData[productId].price,
                    quantity: quantity,
                };
            }
        }

        // Send the cart data to the server to clear and update session
        fetch('checkout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(cartData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
              //  alert("Checkout successful and cart updated.");
				            window.location.href = "chackout.php"; // Replace with the actual URL of the page you want to redirect to
                previousCartData = {}; // Clear local cart data
                updateCartTable(previousCartData); // Refresh cart display
            } else {
                alert("Error during checkout.");
            }
        })
        .catch(error => console.error('Error:', error));
    }
    // JavaScript for AJAX polling
    let previousCartData = null;

    function fetchCartData() {
        console.log("fetchCartData is running");

        fetch('fetch_cart.php')
            .then(response => response.json())
            .then(data => {
                console.log("Fetched Data:", data);
                const cartChanged = JSON.stringify(data) !== JSON.stringify(previousCartData);
                if (cartChanged) {
                    previousCartData = data;
                    updateCartTable(data);
                }
            })
            .catch(error => console.error('Error fetching cart data:', error));
    }

    function updateCartTable(cartItems) {
        const tableBody = document.getElementById('cart-table-body');
        tableBody.innerHTML = ''; // Clear existing rows

        let subtotal = 0;
        for (const productId in cartItems) {
            const item = cartItems[productId];
            if (!item) {
                console.warn(`Item with productId ${productId} is undefined. Skipping.`);
                continue;
            }

            const price = parseFloat(item.price) || 0;
            let quantity = parseInt(item.quantity, 10) || 0;
            const totalPrice = price * quantity;
            subtotal += totalPrice;

            const row = document.createElement('tr');
            row.innerHTML = `
                <th scope="row">
                    <div class="d-flex align-items-center">
                        <img src="${item.image}" class="img-fluid me-5 rounded-circle" style="width: 80px; height: 80px;" alt="">
                    </div>
                </th>
                <td><p class="mb-0 mt-4">${item.name}</p></td>
                <td><p class="mb-0 mt-4">RM${price.toFixed(2)}</p></td>
                <td>
                    <div class="input-group quantity mt-4" style="width: 100px;">
                        <div class="input-group-btn">
                            <button class="btn btn-sm btn-minus rounded-circle bg-light border" onclick="changeQuantity('${productId}', -1)">
                                <i class="fa fa-minus"></i>
                            </button>
                        </div>
                        <input type="text" class="form-control form-control-sm text-center border-0" id="quantity-${productId}" value="${quantity}" readonly>
                        <div class="input-group-btn">
                            <button class="btn btn-sm btn-plus rounded-circle bg-light border" onclick="changeQuantity('${productId}', 1)">
                                <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>
                </td>
                <td><p class="mb-0 mt-4" id="total-${productId}">RM${totalPrice.toFixed(2)}</p></td>
                <td>
                    <form method="post" action="">
                        <input type="hidden" name="remove_product_id" value="${productId}">
                        <button type="submit" class="btn btn-md rounded-circle bg-light border mt-4">
                            <i class="fa fa-times text-danger"></i>
                        </button>
                    </form>
                </td>
            `;
            tableBody.appendChild(row);
        }

        // Update subtotal and total
        document.getElementById('subtotal').innerText = `RM${subtotal.toFixed(2)}`;
        const shipping = 3.00;
        document.getElementById('total').innerText = `RM${(subtotal + shipping).toFixed(2)}`;
    }

    // Function to change quantity and update the UI
    function changeQuantity(productId, change) {
        const quantityInput = document.getElementById(`quantity-${productId}`);
        let newQuantity = parseInt(quantityInput.value) + change;
        if (newQuantity < 1) newQuantity = 1; // Prevent quantity from going below 1
        quantityInput.value = newQuantity;

        // Update total for this item
        const price = parseFloat(previousCartData[productId].price) || 0;
        const newTotal = price * newQuantity;
        document.getElementById(`total-${productId}`).innerText = `$${newTotal.toFixed(2)}`;

        // Update subtotal and grand total
        updateTotals();
    }

    function updateTotals() {
        let newSubtotal = 0;
        for (const productId in previousCartData) {
            const item = previousCartData[productId];
            const quantity = parseInt(document.getElementById(`quantity-${productId}`).value) || 0;
            newSubtotal += item.price * quantity;
        }
        document.getElementById('subtotal').innerText = `$${newSubtotal.toFixed(2)}`;
        const shipping = 3.00;
        document.getElementById('total').innerText = `$${(newSubtotal + shipping).toFixed(2)}`;
    }

    // Call fetchCartData immediately to load initial cart data
    fetchCartData();

    // Poll the server every 5 seconds
    setInterval(fetchCartData, 5000);
</script>





        <!-- Cart Page End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    </body>

</html>