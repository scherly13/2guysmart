<?php
$conn = new mysqli("localhost", "root", "", "mart");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = 1; // Replace with dynamic user_id as needed

$cart_query = "
    SELECT c.product_id, c.quantity, p.name, p.price, p.image_url 
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
";
$stmt = $conn->prepare($cart_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$db_cart_result = $stmt->get_result();

$cart_items = [];
while ($row = $db_cart_result->fetch_assoc()) {
    $cart_items[] = [
        'product_id' => $row['product_id'],
        'name' => $row['name'],
        'price' => $row['price'],
        'quantity' => $row['quantity'],
        'image' => $row['image_url'],
        'total' => $row['price'] * $row['quantity']
    ];
}

echo json_encode(['cart_items' => $cart_items]);
$stmt->close();
$conn->close();
?>