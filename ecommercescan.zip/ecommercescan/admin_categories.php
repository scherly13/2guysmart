<?php
session_start();
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
     header("Location: login.php");
     exit;
 }
// Database connection
include('database.php');


// Add a new category
if (isset($_POST['add_category'])) {
    $name = $_POST['category_name'];
    $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: admin_categories.php");
}

// Edit an existing category
if (isset($_POST['edit_category'])) {
    $id = $_POST['category_id'];
    $name = $_POST['category_name'];
    $stmt = $conn->prepare("UPDATE categories SET name=? WHERE id=?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: admin_categories.php");
}

// Delete a category
if (isset($_POST['delete_category'])) {
    $id = $_POST['category_id'];
    $stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    header("Location: admin_categories.php");
}

// Fetch all categories
function fetchCategories($conn) {
    $query = "SELECT * FROM categories";
    $result = $conn->query($query);
    return $result;
}

// Database connection
$categories_result = fetchCategories($conn);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Fruitables - Manage Categories</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet"></head>
<body>
<?php include('sidebar.php')?>

<div class="container py-5">
    <h1 class="mb-4">Manage Categories</h1>

    <!-- Category Management Table -->
    <div class="mb-4">
        <h3>Add New Category</h3>
        <form method="POST" class="mb-3">
            <div class="input-group">
                <input type="text" name="category_name" class="form-control" placeholder="Enter category name" required>
                <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
            </div>
        </form>
    </div>

    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Category ID</th>
                <th>Category Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($category = $categories_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $category['id']; ?></td>
                    <td><?php echo $category['name']; ?></td>
                    <td>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                            <button type="button" class="btn btn-warning btn-sm" onclick="setEditCategory('<?php echo $category['id']; ?>', '<?php echo $category['name']; ?>')">Edit</button>
                        </form>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                            <button type="submit" name="delete_category" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Edit Category Modal -->
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="category_id" name="category_id">
                <div class="mb-3">
                    <label for="category_name" class="form-label">Category Name</label>
                    <input type="text" id="category_name" name="category_name" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="edit_category" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function setEditCategory(id, name) {
    document.getElementById('category_id').value = id;
    document.getElementById('category_name').value = name;
    var editModal = new bootstrap.Modal(document.getElementById('editCategoryModal'), {});
    editModal.show();
}
</script>

</body>
</html>
