<?php
session_start();

// Check if an order ID is provided (e.g., passed from the order confirmation page)
if (!isset($_GET['order_id'])) {
    echo "Order ID not specified.";
    exit;
}

$order_id = $_GET['order_id'];

// Connect to the database
include('database.php');


// Retrieve order details
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();
$order = $order_result->fetch_assoc();
$stmt->close();

if (!$order) {
    echo "Order not found.";
    exit;
}

// Retrieve order items
$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice - Order #<?php echo $order_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet"></head>
    <style>
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        .thank-you {
            color: #28a745;
            font-size: 1.25rem;
        }
    </style>
</head>
<body>
<?php include ('sidebar.php'); ?>
<div class="container my-3">
    <button onclick="history.back()" class="btn btn-secondary">Back</button>
</div>
<div class="invoice-container my-5">


    <h2 class="text-center mb-4">Invoice - Order #<?php echo $order_id; ?></h2>
    
    <!-- Billing Details -->
    <h4>Billing Details</h4>
    <p><strong>First Name:</strong> <?php echo htmlspecialchars($order['first_name']); ?></p>
    <p><strong>Last Name:</strong> <?php echo htmlspecialchars($order['last_name']); ?></p>
    <p><strong>Company Name:</strong> <?php echo htmlspecialchars($order['company_name']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
    <p><strong>City:</strong> <?php echo htmlspecialchars($order['city']); ?></p>
    <p><strong>Country:</strong> <?php echo htmlspecialchars($order['country']); ?></p>
    <p><strong>Postcode/Zip:</strong> <?php echo htmlspecialchars($order['postcode']); ?></p>
    <p><strong>Mobile:</strong> <?php echo htmlspecialchars($order['mobile']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>

    <hr>

    <!-- Order Summary -->
    <h4>Order Summary</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $subtotal = 0;
            while ($item = $order_items_result->fetch_assoc()): 
                $subtotal += $item['subtotal'];
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td>RM<?php echo number_format($item['product_price'], 2); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>RM<?php echo number_format($item['subtotal'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-end">Subtotal</td>
                <td>RM<?php echo number_format($subtotal, 2); ?></td>
            </tr>
            <tr>
                <td colspan="3" class="text-end">Shipping</td>
                <td>RM3.00</td>
            </tr>
            <tr>
                <td colspan="3" class="text-end">Total</td>
                <td>RM<?php echo number_format($subtotal + 3, 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <hr>

    <!-- Thank You and Shipping Estimate -->
    <p class="thank-you text-center mt-4">Thank you for your purchase! Your order will be shipped within 3 business days.</p>
</div>

</body>
</html>
