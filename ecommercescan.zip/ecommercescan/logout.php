<?php
session_start(); // Start the session

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page or homepage after logout
echo "<script>
        alert('You have been logged out successfully.');
        window.location.href = 'login.php';
      </script>";
?>
